package com.example.mrwan.db_sqlite;

/**
 * Created by 9x_Mr.Wan on 5/30/2016.
 */
public class Country {
    public final static String TABLE_NAME = "Country";
      public final static String COL_ID = "id";
      public final static String COL_NAME_EN = "nameEn";
       public final static String COL_NAME_VI = "nameVi";
      public final static String COL_FLAG = "flag";
    int id;
    String nameEn;
    String nameVi;
    String flag;

    public Country() {
    }

    public Country(int id, String nameEn, String nameVi, String flag) {
        this.id = id;
        this.nameEn = nameEn;
        this.nameVi = nameVi;
        this.flag = flag;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameVi() {
        return nameVi;
    }

    public void setNameVi(String nameVi) {
        this.nameVi = nameVi;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}