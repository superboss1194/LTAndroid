package com.example.mrwan.db_sqlite;

import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.lv);
        button = (Button) findViewById(R.id.btnLoad);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //buoc 1: copy file db vao trong bo nho trong
                //kiem tra file db da ton tai trong internal chua,
                // da ton tai --> bo qua
                // chua ton tai --> copy

                String path = getFilesDir().getAbsolutePath() + "/CountryDB";
                File file = new File(path);
                if (!file.exists()) {
                    AssetManager assetManager = getAssets();
                    try {
                        BufferedInputStream bis = new BufferedInputStream(assetManager.open("CountryDB"));
                        FileOutputStream fos = openFileOutput("CountryDB", Context.MODE_PRIVATE);
                        byte[] buffer = new byte[512];
                        int i = 0;
                        while ((i = bis.read(buffer)) != -1) {
                            fos.write(buffer, 0, i);
                        }
                        bis.close();
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                //B2: mo file db
                SQLiteDatabase sqLiteDatabase = SQLiteDatabase.openDatabase(path,null,SQLiteDatabase.OPEN_READONLY);
                // B3: TRUY VAN DL
                Cursor cursor = sqLiteDatabase.query(Country.TABLE_NAME,null,null,null,null,null,Country.COL_NAME_EN + "ASC");
                // trong qua trinh quy van co loi hay khong
                List<Country> countries = null;
                if(cursor != null){
                    if(cursor.moveToFirst()){
                        //chac chan chua co du lieu --> lay dl
                        countries = new ArrayList<>();
                        do{
                            Country country = new Country();
                            country.setId(cursor.getInt(cursor.getColumnIndex(Country.COL_ID)));
                            country.setNameEn(cursor.getString(cursor.getColumnIndex(Country.COL_NAME_EN)));
                            country.setNameVi(cursor.getString(cursor.getColumnIndex(Country.COL_NAME_VI)));
                            country.setFlag(cursor.getString(cursor.getColumnIndex(Country.COL_FLAG)));
                            countries.add(country);
                        }while (cursor.moveToNext());
                    }
                    cursor.close();
                    sqLiteDatabase.close();
                }
                //b4: load ds coutries len lv
                CountryAdapter countryAdapter = new CountryAdapter(MainActivity.this,R.layout.item_list,countries);
                listView.setAdapter(countryAdapter);

            }
        });
    }

}
