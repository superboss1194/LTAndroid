package com.example.mrwan.db_sqlite;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by 9x_Mr.Wan on 5/30/2016.
 */
public class CountryAdapter  extends ArrayAdapter<Country>{
    Context context;
    int Res;
    List<Country> countries;

    public CountryAdapter(Context context, int res, List<Country> object) {
        super(context,res, object);
        this.context = context;
        Res = res;
        this.countries = object;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(convertView == null){
            LayoutInflater  layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(Res,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.tvNameEn = (TextView) convertView.findViewById(R.id.nameEn);
            viewHolder.tvNameVi = (TextView) convertView.findViewById(R.id.nameVi);
            viewHolder.ivFlag = (ImageView) convertView.findViewById(R.id.flag);
            convertView.setTag(viewHolder);
        }else
            viewHolder = (ViewHolder) convertView.getTag();
        viewHolder.tvNameEn.setText(countries.get(position).getNameEn());
        viewHolder.tvNameVi.setText(countries.get(position).getNameVi());
        return convertView;
    }
    class ViewHolder {
              TextView tvNameEn;
               TextView tvNameVi;
               ImageView ivFlag;
           }
}
