package com.example.mrwan.contentprovidercontact.view;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.mrwan.contentprovidercontact.Detail_Activity;
import com.example.mrwan.contentprovidercontact.R;
import com.example.mrwan.contentprovidercontact.module.Contact;
import com.example.mrwan.contentprovidercontact.module.Email;
import com.example.mrwan.contentprovidercontact.module.Phone;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "CONTACT";
    ListView listView;
    List<Contact> contacts;
    List<String> displayNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        initData();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, displayNames);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ContentResolver contentResolver = getContentResolver();
                Cursor cursor = contentResolver.query(ContactsContract.Data.CONTENT_URI,

                        null, ContactsContract.Data.RAW_CONTACT_ID + "= ?",
                        new String[]{contacts.get(position).get_id() + ""},
                        null, null);
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        do {
                            //kiem tra mime_type --> record thuoc loai nao
                            String mimeType = cursor.getString(cursor.getColumnIndex(ContactsContract.Data.MIMETYPE));
                            Phone phone = new Phone();
                            Email email = new Email();
                            switch (mimeType) {
                                case ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE:

                                     phone.setNumberPhone(cursor.getString(
                                            cursor.getColumnIndex(
                                                    ContactsContract.CommonDataKinds.Phone.NUMBER)));
                                    phone.setType(cursor.getInt(
                                            cursor.getColumnIndex(
                                                    ContactsContract.CommonDataKinds.Phone.TYPE)));
                                    //TODO: chuyen type tu int --> string
                                    Log.d(TAG, "data: phone: " + phone.getNumberPhone() + "/" +
                                            ContactsContract.CommonDataKinds.Phone.getTypeLabel(getResources(),
                                                    phone.getType(),""));
                                    contacts.get(position).addPhone(phone);
                                    break;
                                case ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE:
                                    email.setEmail(cursor.getString(
                                            cursor.getColumnIndex(
                                                    ContactsContract.CommonDataKinds.Email.ADDRESS)));
                                    email.setType(cursor.getInt(
                                            cursor.getColumnIndex(
                                                    ContactsContract.CommonDataKinds.Email.TYPE)));
                                    Log.d(TAG, "data: email: " + email.getEmail() + "/" +
                                            ContactsContract.CommonDataKinds.Email.getTypeLabel(getResources(),
                                                    email.getType(),""));
                                    contacts.get(position).addEmail(email);
                                    //TODO: get thong tin email
                                    break;

                            }
                            Intent intent = new Intent(MainActivity.this,Detail_Activity.class);
                            intent.putExtra("phone",phone.getNumberPhone());

                            intent.putExtra("email",email.getEmail());


                            startActivity(intent);

                        } while (cursor.moveToNext());
                    }
                }

            }
        });

    }

    void initData() {
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.RawContacts.CONTENT_URI,
                new String[]{ContactsContract.RawContacts._ID, ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY},
                null, null, null, null);
        contacts = new ArrayList<>();
        displayNames = new ArrayList<>();
        if (cursor != null) {

            if (cursor.moveToFirst()) {
                do {
                    Contact contact = new Contact();
                    contact.set_id(cursor.getLong(cursor.getColumnIndex(ContactsContract.RawContacts._ID)));
                    contact.setDisplayName(cursor.getString(cursor.getColumnIndex(ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY)));

                    contacts.add(contact);
                    displayNames.add(contact.getDisplayName());

                } while (cursor.moveToNext());
            }
        }
    }
}
