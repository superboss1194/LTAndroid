package com.example.mrwan.contentprovidercontact;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class Detail_Activity extends AppCompatActivity {
    Toolbar toolbar;
    ImageView imageView;
    TextView tvTen,tvPhone,tvEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        imageView = (ImageView) findViewById(R.id.ivnguoi);
        tvTen = (TextView) findViewById(R.id.tvTenDetail);
       tvPhone = (TextView) findViewById(R.id.tvPhoneDetail);
        tvEmail = (TextView) findViewById(R.id.tvEmailDetail);

        String phone = getIntent().getStringExtra("phone");

        String email = getIntent().getStringExtra("email");


        tvPhone.setText(phone );
        tvEmail.setText(email);
    }
}
