package com.example.mrwan.contentprovidercontact.module;

/**
 * Created by 9x_Mr.Wan on 6/7/2016.
 */

public class Email {
    String email;
    int type;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
