package com.example.mrwan.contentprovidercontact.database.dao;

/**
 * Created by 9x_Mr.Wan on 6/7/2016.
 */

public class ContactDAO {

}
