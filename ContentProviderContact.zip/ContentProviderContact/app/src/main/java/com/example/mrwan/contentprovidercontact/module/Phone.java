package com.example.mrwan.contentprovidercontact.module;

/**
 * Created by 9x_Mr.Wan on 6/7/2016.
 */

public class Phone {
    String numberPhone;
    int Type;

    public String getNumberPhone() {
        return numberPhone;
    }

    public void setNumberPhone(String numberPhone) {
        this.numberPhone = numberPhone;
    }

    public int getType() {
        return Type;
    }

    public void setType(int type) {
        Type = type;
    }
}
