package com.example.mrwan.contentprovidercontact.view;

/**
 * Created by 9x_Mr.Wan on 6/7/2016.
 */

public class ContactAdapter {

}
